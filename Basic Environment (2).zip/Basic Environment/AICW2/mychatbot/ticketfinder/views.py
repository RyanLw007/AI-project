from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods




def chat_interface(request):
    return render(request, 'ticketfinder/chat_interface.html')

def get_response(request):
    user_input = request.GET.get('message', '')
    response = {'response': f'Echo: {user_input}'}
    return JsonResponse(response)